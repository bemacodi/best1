#!/bin/bash

free -mh | grep Mem | awk '{print $3}'

#top > $HOME/Público/top.txt

# kill -INT $!

# awk 'NR==4{print $8}' $HOME/Público/top.txt

