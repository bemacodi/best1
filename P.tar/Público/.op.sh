#!/bin/bash

cp /home/benjamin/Imágenes/xico/libffmpeg.so /usr/lib/opera/
