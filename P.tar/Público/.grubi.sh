#!/bin/bash
sudo grub-install /dev/sda7

# sudo update-grub
pac os-prober

sudo grub-mkconfig -o /boot/grub/grub.cfg
sudo update-grub


